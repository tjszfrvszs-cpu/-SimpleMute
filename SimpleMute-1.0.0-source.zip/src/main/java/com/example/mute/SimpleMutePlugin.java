package com.example.mute;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public final class SimpleMutePlugin extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private final Set<UUID> muted = new HashSet<>();
    private final Set<String> privateMessageCommands = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadMutedPlayers();
        loadPrivateMessageCommands();

        getServer().getPluginManager().registerEvents(this, this);
        getCommand("mute").setExecutor(this);
        getCommand("mute").setTabCompleter(this);
        getCommand("unmute").setExecutor(this);
        getCommand("unmute").setTabCompleter(this);

        getLogger().info("SimpleMute enabled. Loaded " + muted.size() + " muted player(s).");
    }

    private void loadMutedPlayers() {
        muted.clear();
        for (String value : getConfig().getStringList("muted-players")) {
            try {
                muted.add(UUID.fromString(value));
            } catch (IllegalArgumentException ignored) {
                getLogger().warning("Ignoring invalid UUID in muted-players: " + value);
            }
        }
    }

    private void loadPrivateMessageCommands() {
        privateMessageCommands.clear();
        for (String command : getConfig().getStringList("private-message-commands")) {
            privateMessageCommands.add(command.toLowerCase(Locale.ROOT));
        }
    }

    private void saveMutedPlayers() {
        getConfig().set("muted-players", muted.stream().map(UUID::toString).sorted().toList());
        saveConfig();
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        if (!muted.contains(event.getPlayer().getUniqueId())) {
            return;
        }

        event.setCancelled(true);
        event.getPlayer().sendMessage(Component.text(ChatColor.RED + "You are muted and cannot chat."));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (!muted.contains(player.getUniqueId())) {
            return;
        }

        String raw = event.getMessage();
        if (raw == null || raw.length() < 2 || raw.charAt(0) != '/') {
            return;
        }

        String withoutSlash = raw.substring(1).trim();
        if (withoutSlash.isEmpty()) {
            return;
        }

        String label = withoutSlash.split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
        int namespaceSeparator = label.lastIndexOf(':');
        if (namespaceSeparator >= 0) {
            label = label.substring(namespaceSeparator + 1);
        }

        if (privateMessageCommands.contains(label)) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "You are muted and cannot send private messages.");
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("simplemute.mute")) {
            sender.sendMessage(ChatColor.RED + "You do not have permission to use this command.");
            return true;
        }

        if (args.length != 1) {
            sender.sendMessage(ChatColor.RED + "Usage: /" + command.getName() + " <player>");
            return true;
        }

        Player online = Bukkit.getPlayerExact(args[0]);
        OfflinePlayer target = online != null ? online : Bukkit.getOfflinePlayer(args[0]);

        if (target.getName() == null) {
            sender.sendMessage(ChatColor.RED + "That player could not be found.");
            return true;
        }

        boolean isMute = command.getName().equalsIgnoreCase("mute");
        if (isMute) {
            if (!muted.add(target.getUniqueId())) {
                sender.sendMessage(ChatColor.YELLOW + target.getName() + " is already muted.");
                return true;
            }
            saveMutedPlayers();
            sender.sendMessage(ChatColor.GREEN + "Muted " + target.getName() + ".");
            if (online != null) {
                online.sendMessage(ChatColor.RED + "You have been muted. You cannot chat or send private messages.");
            }
        } else {
            if (!muted.remove(target.getUniqueId())) {
                sender.sendMessage(ChatColor.YELLOW + target.getName() + " is not muted.");
                return true;
            }
            saveMutedPlayers();
            sender.sendMessage(ChatColor.GREEN + "Unmuted " + target.getName() + ".");
            if (online != null) {
                online.sendMessage(ChatColor.GREEN + "You have been unmuted. You can chat again.");
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) {
            return List.of();
        }

        String prefix = args[0].toLowerCase(Locale.ROOT);
        List<String> names = new ArrayList<>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) {
                names.add(player.getName());
            }
        }
        return names;
    }
}
